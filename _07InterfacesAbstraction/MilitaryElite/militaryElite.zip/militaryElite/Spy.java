package militaryElite;

public interface Spy extends Soldier {

    String getCodeNumber();
}
