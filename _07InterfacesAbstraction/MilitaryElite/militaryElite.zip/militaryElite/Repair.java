package militaryElite;

public interface Repair {

    String getPartName();
    int getHoursWorked();
}
