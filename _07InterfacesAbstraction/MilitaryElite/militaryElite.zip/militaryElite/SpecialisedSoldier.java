package militaryElite;

public interface SpecialisedSoldier extends Private {

    Corps getCorps();
}
