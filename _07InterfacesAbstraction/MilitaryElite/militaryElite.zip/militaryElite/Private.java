package militaryElite;

public interface Private extends Soldier {

    double getSalary();
}
