package militaryElite;

public interface Engineer extends SpecialisedSoldier {

    void addRepairs(Repair repair);
    Iterable<Repair> getRepairs();
}
