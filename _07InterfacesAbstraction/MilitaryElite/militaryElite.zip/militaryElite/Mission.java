package militaryElite;

public interface Mission {

    String getCodeName();
    String getState();
    void completeMission();
}
