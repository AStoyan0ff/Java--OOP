package militaryElite;

public interface LieutenantGeneral extends Private {

    void addPrivate(Private p);
    Iterable<Private> getPrivates();
}
