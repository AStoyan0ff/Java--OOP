package birthday;

public interface Birthable {

    String getBirthDate();
}
