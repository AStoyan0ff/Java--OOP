package collection;

public interface MyList extends AddRemovable {

    public interface MyLists extends AddRemovable{
        int getUsed();
    }
}
