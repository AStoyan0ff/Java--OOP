package multiple;

public interface Birthable {

    String getBirthDate();
}
