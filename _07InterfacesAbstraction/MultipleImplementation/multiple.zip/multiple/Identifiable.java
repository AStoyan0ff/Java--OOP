package multiple;

public interface Identifiable {

    String getId();
}
