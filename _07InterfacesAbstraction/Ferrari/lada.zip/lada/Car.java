package lada;

public interface Car {

    String brakes();
    String gas();
}
