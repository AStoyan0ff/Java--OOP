package telephony;
import java.util.List;

public class Smartphone implements Callable, Browsable {

    private List<String> numberList;
    private List<String> urlsList;

    public Smartphone(List<String> numberList, List<String> urlsList) {

        this.numberList = numberList;
        this.urlsList = urlsList;
    }

    @Override
    public String call() {
        StringBuilder buff = new StringBuilder();

        for (String n : numberList) {

            if (!n.matches("\\d+")) {
                buff.append("Invalid number!").append(System.lineSeparator());
            }
            else {
                buff.append("Calling... ").append(n).append(System.lineSeparator());
            }
        }
        return buff.toString().trim();
    }

    @Override
    public String browse() {
        StringBuilder buff = new StringBuilder();

        for (String url : urlsList) {

            if (bDigit(url)) {
                buff.append("Invalid URL!").append(System.lineSeparator());
            } else {
                buff.append("Browsing: ").append(url).append("!").append(System.lineSeparator());
            }
        }
        return buff.toString().trim();
    }

    private boolean bDigit(String s) {
        for (char c : s.toCharArray()) {

            if (Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }
}
