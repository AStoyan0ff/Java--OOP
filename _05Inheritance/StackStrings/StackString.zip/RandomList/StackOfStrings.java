package RandomList;
import java.util.ArrayList;

public class StackOfStrings {

    private ArrayList<String> data;

    public StackOfStrings() {
        this.data = new ArrayList<>();
    }

    public void push(String element) {
        data.add(element);
    }

    public String pop() {

        if (!isEmpty()) {
            return data.removeLast();
        }
        return null;
    }
    public String peek() {

        if (!isEmpty()) {
            return data.getLast();
        }
        return  null;
    }

    public boolean isEmpty() {
        return data.isEmpty();
    }
}
