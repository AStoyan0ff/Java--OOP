package hero;

public class Knight extends Hero {

    public Knight(String username, int level) {
        super(username, level);
    }
}
