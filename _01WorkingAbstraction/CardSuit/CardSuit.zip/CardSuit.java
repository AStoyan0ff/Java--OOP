package _01WorkingAbstraction.CardSuit;

public enum CardSuit {

    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;

    CardSuit() {}
}
