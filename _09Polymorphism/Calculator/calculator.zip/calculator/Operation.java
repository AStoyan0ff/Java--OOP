package calculator;

public interface Operation {
    void execute(int operand);

}
