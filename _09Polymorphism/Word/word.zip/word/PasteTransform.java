package word;

import java.util.function.Supplier;

public class PasteTransform extends  TextTransform {

    private Supplier<String> lastCutSupplier;

    public void setLastCutSupplier(Supplier<String> supplier) {
        this.lastCutSupplier = supplier;
    }

    @Override
    public void invokeOn(StringBuilder text, int startIndex, int endIndex) {
        String toPaste = this.lastCutSupplier.get();

        text.delete(startIndex, endIndex);
        text.insert(startIndex, toPaste);
    }
}
