package word;

public abstract class TextTransform {

    public abstract void invokeOn(StringBuilder text, int startIndex, int endIndex);
}

