package word;

public class Initialization {

    public static CommandInterface buildCmdInterface(StringBuilder buff) {
        return new CommandImpl(buff);
    }
}
