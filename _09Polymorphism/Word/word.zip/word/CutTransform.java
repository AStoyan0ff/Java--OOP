package word;

import java.util.function.Consumer;

public class CutTransform extends TextTransform {

    private Consumer<String> lastCutConsumer;

    public void setLastCutConsumer(Consumer<String> consumer) {
        this.lastCutConsumer = consumer;
    }

    @Override
    public void invokeOn(StringBuilder buff, int startIndex, int endIndex) {

        String cutText = buff.substring(startIndex, endIndex);
        this.lastCutConsumer.accept(cutText);

        buff.delete(startIndex, endIndex);
    }
}
