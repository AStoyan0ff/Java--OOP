package word;

public class UppercaseTransform extends TextTransform {

    @Override
    public void invokeOn(StringBuilder sb, int startIndex, int endIndex) {

        for (int pos = startIndex; pos < endIndex; pos++) {

            char upper = Character.toUpperCase(sb.charAt(pos));
            sb.setCharAt(pos, upper);
        }
    }
}
