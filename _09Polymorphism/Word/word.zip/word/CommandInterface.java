package word;

public interface CommandInterface {
    Command handle(String input);
}
