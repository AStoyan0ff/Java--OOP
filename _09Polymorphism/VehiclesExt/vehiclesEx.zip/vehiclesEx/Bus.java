package vehiclesEx;

public class Bus extends Vehicle {
    private static final double EXTRA_CONSUMPTION = 1.4;

    public Bus(double fuelQuantity, double fuelConsumption, double tankCapacity) {
        super(fuelQuantity, fuelConsumption, tankCapacity);
    }

    public String noPeopleCar(double distance) {
        setConsumption(getConsumption() + EXTRA_CONSUMPTION);

        String res = super.drive(distance);

        setConsumption(getConsumption() - EXTRA_CONSUMPTION);
        return res;
    }

    public String DriveEmpty(double distance) {
        return super.drive(distance);
    }
}

